package Assignment;
import java.util.Scanner;
public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Q 3 wap to print cube of 1 to 5 number.
		 int n = 5;
	      System.out.println("Enter a number ::");
	      Scanner sc = new Scanner(System.in);
	      int num = sc.nextInt();
	      System.out.println("Cube of the given number is "+(num*num*num));

	}

}
