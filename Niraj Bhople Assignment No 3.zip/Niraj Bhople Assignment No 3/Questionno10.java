package Assignment;

public class Questionno10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//pattern 3
		int n=4;
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<=n-i+1; j++)
				
		
		{
			System.out.print((char)('A'+ (j-1)) + " ");
		}
			System.out.println();
		}
	}

}
