package Assignment;
import java.util.Scanner;
public class Question4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,count=0;
		System.out.println("Entre any Number");
		Scanner r=new Scanner (System.in);
		n=r.nextInt();
		
		for(int i=1; i<=n; i++)
		{
			if(n%i==0)
			{
				count++;
				
			}
		}
			
		if(count==2)
		System.out.println("prime Number");
		else
			System.out.println(" Not prime Number");
			
		

	}

}
