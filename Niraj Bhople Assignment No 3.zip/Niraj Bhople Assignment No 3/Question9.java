package Assignment;

public class Question9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Q 9  print patterns like 
		int i,j;
		for(i=1; i<=5; i++)
		{
			for(j=1; j<=i; j++)
			{
				System.out.print("*");
			}
		
        System.out.println("\n");
		}
	}

}
