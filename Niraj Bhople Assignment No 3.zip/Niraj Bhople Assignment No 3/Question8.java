package Assignment;

public class Question8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Q 8 wap to print prime numbers between 2 to 20
		int ct=0,n=0,i=1,j=1;  
		while(n<8)  
		{  
		j=1;  
		ct=0;  
		while(j<=i)  
		{  
		if(i%j==0)  
		ct++;  
		j++;   
		}  
		if(ct==2)  
		{  
		System.out.printf("%d ",i);  
		n++;  
		}  
		i++;  
		}    
			


	}

}
