package Assignment;

public class Question11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// pattern no 4
		char ch;
		int space = 0;
		for(int i=0; i<=3; i++)
		{
			ch='a';
			for (int j=3; j>=i; j--)
			{
				System.out.print(ch+" ");
				ch++;
			}
			for (int j=0;j<space;j++)
			{
				System.out.print(" ");
			}
			for (int j=3; j>=i;j--)
			{
				ch--;
				System.out.print(ch+" ");
			}
			space+=2;
			System.out.println();
		}

	}

}
