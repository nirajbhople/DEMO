package Assignment;
import java.util.Scanner;
public class Question6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // wap to print factorial of a number
		int n, fact=1;
		System.out.println("Entre any Number");
		Scanner r=new Scanner (System.in);
		n=r.nextInt();
		
		for(int i=1; i<=n; i++)
		{
			fact = fact* i;
		}
		System.out.println("Factorial " + fact);
	}

}
