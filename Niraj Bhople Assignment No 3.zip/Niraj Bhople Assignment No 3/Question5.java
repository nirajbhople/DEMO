package Assignment;
import java.util.Scanner;
public class Question5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Q 5 wap to print fibonacci series using for loop i.e adding last two results
		
		int term,a=0,b=1,c;
		System.out.println("Ente term");
		Scanner r=new Scanner(System.in);
		term=r.nextInt();
		for(int i=1;i<=term;i++) {
			
			System.out.println(a+" ");
			c=a+b;
			a=b;
			b=c;
			

		}
		
		

	}

}
