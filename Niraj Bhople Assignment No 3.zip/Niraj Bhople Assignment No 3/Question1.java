package Assignment;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int one = 'a'  / 'a' ;
		int ten ="**********".length();
		
		for (int i = one ;i<=(ten * ten ); i++) {
			System.out.println(i);
		}
				

	}

}
