package Assignment;
import java.util.Scanner;
public class Question7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Q 7wap to ask a number from user and print table of that number
        int num;
        System.out.println("Entre any Number");
        Scanner r=new Scanner(System.in);
        num=r.nextInt();
        
        for(int i=1; i<=10; i++)
        {
        	System.out.println(num+"*"+i+"="+num*i);
        	
        
        }
        
	}

}
